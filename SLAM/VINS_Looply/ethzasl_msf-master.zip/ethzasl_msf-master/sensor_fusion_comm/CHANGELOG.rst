^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package sensor_fusion_comm
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.1 (2014-06-16)
------------------
* Initial release.
* Contributors: Markus Achtelik, georgwi, markusachtelik
