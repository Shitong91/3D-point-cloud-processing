^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package msf_updates
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.1 (2014-06-16)
------------------
* Initial release.
* Contributors: Markus Achtelik, Simon Lynen, asl, georgwi, markusachtelik, omaris, simonlynen
