^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package msf_core
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.1 (2014-06-16)
------------------
* Initial release.
* Contributors: Markus Achtelik, Simon Lynen, asl, georgwi, markusachtelik, omaris, simonlynen, wueestm
