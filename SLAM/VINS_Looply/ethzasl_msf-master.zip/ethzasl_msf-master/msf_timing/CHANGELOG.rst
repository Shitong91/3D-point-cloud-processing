^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package msf_timing
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.1 (2014-06-16)
------------------
* Initial release.
* Contributors: Markus Achtelik, Simon Lynen, markusachtelik, simonlynen
