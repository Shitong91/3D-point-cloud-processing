For the VLDB'15 evaluation, one can download data using the script ./get_data_vldb2015.sh

To download SISAP'13 and NIPS'13 data sets use the script:
./get_data_nips2013.sh

You can download sub sets separately using scripts, e.g:

* download_wikipedia_lsi128.sh (~3GB)
* download_wikipedia_sparse.sh (~5GB)
* download_cayton.sh   (~0.5GB)
* download_colors.sh   (very small)




