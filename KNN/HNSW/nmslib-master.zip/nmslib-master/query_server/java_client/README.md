**Note**: requires Java 8
