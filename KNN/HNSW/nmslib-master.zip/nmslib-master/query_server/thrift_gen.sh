thrift --gen java protocol.thrift
thrift --gen cpp  protocol.thrift
thrift --gen py  protocol.thrift



