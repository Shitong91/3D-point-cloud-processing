This works only if the library is compiled without extras. Just type make. Then you can run tests like this:
```
./sample_standalone_app1 ../sample_data/sift_10k.txt
./sample_standalone_app2 l2 ../sample_data/sift_10k.txt ../sample_data/final128_10K.txt 

```
