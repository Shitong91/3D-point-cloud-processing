
rm -f *.{dep,dpth,log}

rm -f *.{aux,auxlock,log}

